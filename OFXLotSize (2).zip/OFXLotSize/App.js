// OFX Lot Size — Expo + React Native (iOS & Android)
import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import { CATS, CONV, STEPS, DEC } from './src/data';
import { num, usd } from './src/utils';
import { Chip, Field, Row } from './src/components';
import { s } from './src/styles';
import { C } from './src/theme';
import PrivacyPolicy from './src/PrivacyPolicy';
import AdBanner from './src/AdBanner';

export default function App() {
  const [cat, setCat] = useState('forex');
  const [sel, setSel] = useState({ forex: 'EURUSD', metals: 'XAUUSD', indices: 'US100', energy: 'USOIL', crypto: 'BTCUSD' });
  const [contracts, setContracts] = useState({});
  const [rates, setRates] = useState({});
  const [balance, setBalance] = useState('1000');
  const [mode, setMode] = useState('pct');
  const [risk, setRisk] = useState('1');
  const [slv, setSl] = useState('');
  const [tpv, setTp] = useState('');
  const [step, setStep] = useState(0.01);
  const [policy, setPolicy] = useState(false);

  const C0 = CATS[cat];
  const item = C0.items.find((i) => i.id === sel[cat]);
  const isFx = cat === 'forex';
  const contractStr = contracts[item.id] ?? String(item.contract);
  const contract = num(contractStr);
  const conv = CONV[item.quote];
  const rate = conv ? num(rates[conv[0]] ?? '') : 1;
  const unit = isFx ? (item.quote === 'JPY' ? 0.01 : 0.0001) : 1;
  const toUsd = (v) => (!conv ? v : conv[1] === 'div' ? v / rate : v * rate);

  const bal = num(balance), rk = num(risk), sl = num(slv), tp = num(tpv);
  const riskUsd = mode === 'pct' ? (bal * rk) / 100 : rk;
  const ready = riskUsd > 0 && sl > 0 && contract > 0 && (!conv || rate > 0) && (mode === 'usd' || bal > 0);
  const perLot = ready ? toUsd(sl * unit * contract) : 0; // loss per 1.00 lot at the stop loss
  const lots = ready ? Number((Math.floor(riskUsd / perLot / step + 1e-9) * step).toFixed(3)) : 0;
  const actual = lots * perLot;
  const reward = tp > 0 && ready ? lots * toUsd(tp * unit * contract) : 0;

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets>
        <Text style={s.title}>OFX Lot Size</Text>
        <Text style={s.sub}>Know your lot size before you enter the trade.</Text>

        <View style={s.tabs}>
          {Object.keys(CATS).map((k) => <Chip key={k} grow label={CATS[k].label} on={cat === k} onPress={() => setCat(k)} />)}
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 6 }}>
          {C0.items.map((i) => (
            <Chip key={i.id} label={i.id} on={i.id === item.id} onPress={() => setSel({ ...sel, [cat]: i.id })} />
          ))}
        </ScrollView>
        <Text style={[s.hint, { marginBottom: 14 }]}>{item.name}</Text>

        <View style={s.card}>
          <Field label="Account balance (USD)" value={balance} onChange={setBalance} suffix="$" />
          <Text style={s.label}>Risk per trade</Text>
          <View style={[s.inputRow, { marginBottom: 8 }]}>
            <TextInput style={s.input} value={risk} onChangeText={setRisk} keyboardType="decimal-pad" selectTextOnFocus />
            <TouchableOpacity onPress={() => setMode(mode === 'pct' ? 'usd' : 'pct')} style={s.toggle}>
              <Text style={s.toggleT}>{mode === 'pct' ? '%  ⇄  $' : '$  ⇄  %'}</Text>
            </TouchableOpacity>
          </View>
          {mode === 'pct' && (
            <View style={{ flexDirection: 'row', marginBottom: 14 }}>
              {['0.5', '1', '2', '3'].map((p) => <Chip key={p} grow label={p + '%'} on={risk === p} onPress={() => setRisk(p)} />)}
            </View>
          )}
          {mode === 'usd' && <View style={{ height: 6 }} />}
          <Field label={`Stop loss (${C0.unit})`} value={slv} onChange={setSl} ph="e.g. 20" />
          <Field label={`Take profit (${C0.unit}) — optional`} value={tpv} onChange={setTp} ph="e.g. 40" />

          {!isFx && (
            <View style={{ marginBottom: 14 }}>
              <Text style={s.label}>Broker contract size</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                {item.opts.map((o) => (
                  <Chip key={o} label={String(o)} on={contract === o} onPress={() => setContracts({ ...contracts, [item.id]: String(o) })} />
                ))}
              </View>
              <View style={[s.inputRow, { marginTop: 4 }]}>
                <TextInput style={s.input} value={contractStr} onChangeText={(v) => setContracts({ ...contracts, [item.id]: v })} keyboardType="decimal-pad" selectTextOnFocus />
                <Text style={s.suffix}>custom</Text>
              </View>
              <Text style={s.hint}>MT4/MT5: Market Watch → right-click {item.id} → Specification → Contract size.</Text>
            </View>
          )}

          {!!conv && (
            <Field label={`${conv[0]} price (for conversion to USD)`} value={rates[conv[0]] ?? ''} onChange={(v) => setRates({ ...rates, [conv[0]]: v })} ph="current price" />
          )}

          <Text style={s.label}>Lot step (broker minimum)</Text>
          <View style={{ flexDirection: 'row' }}>
            {STEPS.map((x) => <Chip key={x} grow label={String(x)} on={step === x} onPress={() => setStep(x)} />)}
          </View>
        </View>

        <View style={[s.card, { borderColor: C.acc }]}>
          <Text style={s.label}>Lot size</Text>
          {!ready ? (
            <Text style={s.hint}>Enter your stop loss{conv ? ' and the conversion price' : ''} to see the lot size.</Text>
          ) : (
            <>
              <Text style={s.big}>{lots.toFixed(DEC[step])}<Text style={s.bigU}> lot</Text></Text>
              {lots === 0 && <Text style={[s.hint, { color: C.bad }]}>Below your broker's minimum lot. Reduce the stop loss or raise the risk.</Text>}
              <Row k="Risk target" v={usd(riskUsd)} />
              <Row k="Actual risk at stop loss" v={`${usd(actual)}${bal > 0 ? `  (${((actual / bal) * 100).toFixed(2)}%)` : ''}`} color={C.bad} />
              <Row k="Loss per 1.00 lot" v={usd(perLot)} />
              <Row k="Position size" v={`${+(lots * contract).toFixed(4)} units`} />
              {reward > 0 && <Row k="Potential profit" v={usd(reward)} color={C.ok} />}
              {reward > 0 && <Row k="Risk : reward" v={`1 : ${(tp / sl).toFixed(2)}`} />}
            </>
          )}
        </View>
        <Text style={s.foot}>Education only, not financial advice. Check contract size and pip value in your broker's platform. USD accounts.</Text>
        <TouchableOpacity onPress={() => setPolicy(true)} activeOpacity={0.7} accessibilityRole="link" style={s.linkBtn}>
          <Text style={s.link}>Privacy Policy</Text>
        </TouchableOpacity>
      </ScrollView>
      <AdBanner />
      <PrivacyPolicy visible={policy} onClose={() => setPolicy(false)} />
    </View>
  );
}
