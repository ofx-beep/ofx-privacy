# Google Play checklist

Privacy Policy URL: https://ofx-beep.github.io/ofx-privacy/privacy-policy-ads.html
Developer: OFX | Contact: ofx.tools@gmail.com

## Steps once your developer account is ready
1. Create the app: name **OFX Lot Size**, App, Free.
2. **App content**
   - Privacy policy: paste the URL above.
   - **Ads: Yes** (the app contains ads).
   - **Data safety: Yes**, data is collected and shared through the AdMob SDK. Follow Google's current list at developers.google.com/admob/android/privacy/play-data-disclosure (device identifiers, IP address/approximate location, app interactions, diagnostics; purposes: advertising, analytics, fraud prevention; encrypted in transit).
   - Advertising ID: declare it is used for advertising.
   - Target audience: 18 and over only.
   - Content rating questionnaire: utility app, answer No to violence, sexual content, gambling and so on.
   - App access: all features are available without login.
   - Financial features: the app only calculates, it does not trade or hold money. Choose the option saying it provides no financial features, if asked.
3. Upload the `.aab` from `eas build -p android --profile production`.
4. New personal accounts may need a closed test first. Check the Production page in Play Console.
5. In AdMob, add the app and put the real IDs in the app before the production build.

## Store listing text
**Short description (76 chars):** Fast, accurate lot size calculator for Forex, gold, indices, oil and crypto.

**Full description:**
OFX Lot Size helps you work out the right position size before you enter a trade. Enter your balance, risk, and stop loss, and get the lot size, the money at risk, and your risk-to-reward.

- Forex pairs, metals (gold, silver), indices (Nasdaq 100, S&P 500, Dow, DAX and more), oil and crypto
- Choose your broker's contract size for indices and other markets
- Risk by percent or by money, with take profit and risk-to-reward
- Match your broker's lot step
- No account needed. Your numbers stay on your device.

Contains ads. For education only, not financial advice. Trading carries a high risk of loss.

## Graphics you need
App icon 512x512 PNG, feature graphic 1024x500, at least 2 phone screenshots.
