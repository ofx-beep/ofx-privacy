# OFX Lot Size

Position-size calculator for Forex, Metals, Indices (with broker contract size), Energy and Crypto. Expo + React Native (Android and iOS). Includes a Google AdMob banner and an in-app Privacy Policy.

## Run it (quick preview, no ads)

```
npm install
npx expo install --fix
npx expo start
```
Scan the QR code with **Expo Go**. In Expo Go the ad module is not available, so the app runs without ads. If the phone can't connect: `npx expo start --tunnel`.

## Test with ads (development build)

```
npm install -g eas-cli
eas login
eas build -p android --profile development
npx expo start --dev-client
```
Install the APK from the build link, then open it and connect to the dev server. Test ads use Google's test IDs. **Never click your own live ads.**

## Release build for Google Play

```
eas build -p android --profile production
```
This makes the `.aab` file Play requires.

## Before the production build, replace these 4 values

1. `app.json` > plugins > `androidAppId` (your AdMob Android App ID)
2. `app.json` > plugins > `iosAppId` (your AdMob iOS App ID; use the sample one if you skip iOS)
3. `src/config.js` > `ADS.androidBanner` (banner ad unit ID)
4. `src/config.js` > `ADS.iosBanner` (banner ad unit ID)

Also change `android.package` and `ios.bundleIdentifier` in `app.json` to your own unique ID, and add your release date to `effectiveDate` in `src/config.js` if you want it changed.

See **PLAY_STORE.md** for the Play Console steps and store listing text.

## Structure

```
index.js / App.js       entry and main screen
src/data.js             instruments, contract sizes, currency conversion
src/AdBanner.js         AdMob banner + consent (UMP)
src/PrivacyPolicy.js    in-app Privacy Policy
src/config.js           developer details, policy URL, ad unit IDs
src/components/         Chip, Field, Row
```

Education only, not financial advice.

## Updating the app later

1. Make your change. In `app.json`, raise `version` (for example 1.0.0 to 1.0.1).
2. Run `eas build -p android --profile production`. The Android versionCode goes up automatically.
3. Play Console > your app > Production > Create new release > upload the new `.aab` > add release notes > Review and roll out.
