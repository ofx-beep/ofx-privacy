import React, { useEffect, useState } from 'react';
import { View, Platform } from 'react-native';
import { ADS } from './config';

// Ads need a development/production build. In Expo Go the native module is missing,
// so the app simply runs without ads.
let Ads = null;
try { Ads = require('react-native-google-mobile-ads'); } catch (e) { Ads = null; }

export default function AdBanner() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!Ads) return undefined;
    let alive = true;
    (async () => {
      try {
        await Ads.AdsConsent.gatherConsent(); // Google UMP consent form where required (EEA/UK)
        const info = await Ads.AdsConsent.getConsentInfo();
        if (!info.canRequestAds) return;
        const ads = Ads.default();
        await ads.setRequestConfiguration({ tagForChildDirectedTreatment: false, tagForUnderAgeOfConsent: false });
        await ads.initialize();
        if (alive) setReady(true);
      } catch (e) {
        // If anything fails, show no ad. The calculator keeps working.
      }
    })();
    return () => { alive = false; };
  }, []);

  if (!Ads || !ready) return null;
  const { BannerAd, BannerAdSize, TestIds } = Ads;
  const id = Platform.OS === 'ios' ? ADS.iosBanner : ADS.androidBanner;
  return (
    <View style={{ alignItems: 'center', paddingBottom: 6 }}>
      <BannerAd unitId={__DEV__ || !id ? TestIds.BANNER : id} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </View>
  );
}
