import React from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { s } from './styles';
import { C } from './theme';
import { POLICY as P } from './config';

const sections = [
  ['Information We Collect', [
    `${P.appName} does not require an account and does not ask for your name, email address, phone number, location, contacts, photos or any other personal information.`,
    'The numbers you enter (such as account balance, risk, stop loss, take profit, prices and contract size) are used only on your device to calculate lot size and risk figures. They are kept in the app\'s memory while it is open, are not saved by the app, and are not sent to us or to any server.',
    P.usesAdMob
      ? 'The app itself does not access your location, camera, microphone, contacts or photos. The only network activity comes from the advertising service described under "Advertising and Third-Party Services".'
      : 'The app does not use your location, camera, microphone, contacts or photos, and it does not make network requests of its own.',
    'Google Play and your device\'s operating system may collect technical information (for example crash or diagnostic data, if you have enabled it on your device). That is handled by Google under its own policies and is not collected or accessed by us.',
  ]],
  ['How Information Is Used', [
    'What you enter is used only to calculate position size, risk amounts and risk-to-reward figures on your screen.',
    P.usesAdMob
      ? 'The numbers you enter are not used for advertising and are not shared with advertisers. Information collected by the advertising service is used to show and measure ads and to prevent fraud, as described below.'
      : 'We do not use it for advertising, profiling or analytics, and we do not sell, rent or share it.',
  ]],
  ['Advertising and Third-Party Services', P.usesAdMob ? [
    'This app shows ads provided by Google AdMob. When ads are shown, Google may automatically collect device identifiers such as the Android advertising ID and app set ID, your IP address, device and app information (for example device model, operating system version and app version), diagnostic information and how you interact with ads. This is used to serve and measure ads, which may be personalized, for analytics and to prevent fraud and abuse. Google handles this data under its own policies; we do not receive your advertising ID.',
    'Where required (for example in the European Economic Area and the United Kingdom), you are asked for consent before personalized ads are shown. You can reset your advertising ID or opt out of ad personalization in your Android device settings. More information: policies.google.com/technologies/partner-sites',
  ] : [
    'This version of the app does not show advertising and does not include analytics or other third-party services that collect data about you.',
    'If a future version adds advertising or analytics, this policy will be updated to describe what is collected before that version is released.',
  ]],
  ['Data Security', [
    'Because the app does not collect or transmit the numbers you enter, they stay on your device. Keep your device secure with a screen lock and install system updates. No method of storage or transmission is completely secure, so we cannot guarantee absolute security.',
    ...(P.usesAdMob ? ['Information collected by the advertising service is handled by Google under its own security practices.'] : []),
  ]],
  ['Children\'s Privacy', [
    `${P.appName} is a trading-related calculator intended for adults. It is not directed to children under 13, and we do not knowingly collect personal information from children. If you believe a child has provided personal information, please contact us using the details below.`,
    ...(P.usesAdMob ? ['The advertising in this app is intended for adults and is not directed to children.'] : []),
  ]],
  ['Changes to This Privacy Policy', [
    'We may update this Privacy Policy from time to time. The updated version will be shown in the app and at the Privacy Policy URL below, with a new "Last updated" date. Please review it periodically.',
  ]],
  ['Contact Information', [
    'If you have questions about this Privacy Policy, contact:',
    `Developer: ${P.developer}\nEmail: ${P.email}\nPrivacy Policy URL: ${P.url}`,
  ]],
];

export default function PrivacyPolicy({ visible, onClose }) {
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={s.root}>
        <View style={p.head}>
          <Text style={p.title}>Privacy Policy</Text>
          <TouchableOpacity onPress={onClose} activeOpacity={0.7} style={p.close}>
            <Text style={p.closeT}>Close</Text>
          </TouchableOpacity>
        </View>
        <ScrollView contentContainerStyle={p.body}>
          <Text style={p.date}>Last updated: {P.effectiveDate}</Text>
          <Text style={[p.t, { marginBottom: 14 }]}>This Privacy Policy explains how {P.appName}, provided by {P.developer}, handles information.</Text>
          {sections.map(([h, paras]) => (
            <View key={h} style={s.card}>
              <Text style={p.h}>{h}</Text>
              {paras.map((t, i) => <Text key={i} style={p.t}>{t}</Text>)}
            </View>
          ))}
        </ScrollView>
      </View>
    </Modal>
  );
}

const p = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingBottom: 10 },
  title: { color: C.text, fontSize: 24, fontWeight: '800' },
  close: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.line },
  closeT: { color: C.acc, fontSize: 14, fontWeight: '700' },
  body: { padding: 18, paddingBottom: 60 },
  date: { color: C.mut, fontSize: 12, marginBottom: 8 },
  h: { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 8 },
  t: { color: C.mut, fontSize: 14, lineHeight: 21, marginBottom: 8 },
});
