import React from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { s } from '../styles';

export const Chip = ({ label, on, onPress, grow }) => (
  <TouchableOpacity onPress={onPress} activeOpacity={0.7} style={[s.chip, on && s.chipOn, grow && { flex: 1, alignItems: 'center' }]}>
    <Text style={[s.chipT, on && { color: '#fff' }]}>{label}</Text>
  </TouchableOpacity>
);
