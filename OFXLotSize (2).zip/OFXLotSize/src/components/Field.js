import React from 'react';
import { View, Text, TextInput } from 'react-native';
import { s } from '../styles';
import { C } from '../theme';

export const Field = ({ label, value, onChange, suffix, hint, ph }) => (
  <View style={{ marginBottom: 14 }}>
    <Text style={s.label}>{label}</Text>
    <View style={s.inputRow}>
      <TextInput style={s.input} value={value} onChangeText={onChange} keyboardType="decimal-pad" placeholder={ph} placeholderTextColor={C.mut} selectTextOnFocus />
      {!!suffix && <Text style={s.suffix}>{suffix}</Text>}
    </View>
    {!!hint && <Text style={s.hint}>{hint}</Text>}
  </View>
);
