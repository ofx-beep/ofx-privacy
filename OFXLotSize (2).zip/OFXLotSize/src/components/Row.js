import React from 'react';
import { View, Text } from 'react-native';
import { s } from '../styles';

export const Row = ({ k, v, color }) => (
  <View style={s.row}><Text style={s.rowK}>{k}</Text><Text style={[s.rowV, color && { color }]}>{v}</Text></View>
);
