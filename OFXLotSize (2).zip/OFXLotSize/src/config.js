// Fill these in before publishing to Google Play. They appear in the in-app Privacy Policy.
export const POLICY = {
  appName: 'OFX Lot Size',
  developer: 'OFX', // must match the developer name on your Play Store listing
  email: 'ofx.tools@gmail.com',
  url: 'https://ofx-beep.github.io/ofx-privacy/privacy-policy-ads.html', // replace with the public web page you submit in Play Console
  effectiveDate: 'October 9, 2026',
  usesAdMob: true, // this build includes Google AdMob, so the AdMob disclosure is shown (set false only if you remove ads)
};

// AdMob banner ad unit IDs (from your AdMob account). Empty or dev mode = Google test ads.
// The two AdMob App IDs go in app.json (plugins > react-native-google-mobile-ads).
export const ADS = {
  androidBanner: '', // e.g. 'ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY'
  iosBanner: '',
};
