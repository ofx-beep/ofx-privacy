// quote currency -> USD conversion: [pair whose price you type, operation]
export const CONV = {
  USD: null,
  JPY: ['USDJPY', 'div'], CHF: ['USDCHF', 'div'], CAD: ['USDCAD', 'div'], HKD: ['USDHKD', 'div'],
  EUR: ['EURUSD', 'mul'], GBP: ['GBPUSD', 'mul'], AUD: ['AUDUSD', 'mul'], NZD: ['NZDUSD', 'mul'],
};
export const mk = (a) => a.map(([id, name, contract, opts, quote = 'USD']) => ({ id, name, contract, opts, quote }));
export const FX = 'EURUSD GBPUSD AUDUSD NZDUSD USDJPY USDCHF USDCAD EURGBP EURJPY GBPJPY EURCHF EURAUD EURCAD EURNZD GBPCHF GBPAUD GBPCAD GBPNZD AUDJPY AUDCAD AUDCHF AUDNZD NZDJPY NZDCAD NZDCHF CADJPY CADCHF CHFJPY'.split(' ');
export const IDX = [1, 2, 5, 10, 20, 25, 50];

export const CATS = {
  forex: { label: 'Forex', unit: 'pips', items: FX.map((s) => ({ id: s, name: 'Standard lot = 100,000 units', contract: 100000, opts: [], quote: s.slice(3) })) },
  metals: { label: 'Metals', unit: '$ price move', items: mk([['XAUUSD', 'Gold', 100, [1, 10, 50, 100]], ['XAGUSD', 'Silver', 5000, [1000, 2500, 5000]], ['XPTUSD', 'Platinum', 100, [1, 10, 50, 100]], ['XPDUSD', 'Palladium', 100, [1, 10, 50, 100]]]) },
  indices: { label: 'Indices', unit: 'points', items: mk([
    ['US100', 'Nasdaq 100 (NAS100, USTEC)', 1, IDX], ['US500', 'S&P 500 (SPX500)', 1, IDX], ['US30', 'Dow Jones (DJ30)', 1, IDX], ['US2000', 'Russell 2000', 1, IDX],
    ['GER40', 'DAX (DE40) · EUR', 1, IDX, 'EUR'], ['UK100', 'FTSE 100 · GBP', 1, IDX, 'GBP'], ['JP225', 'Nikkei 225 · JPY', 1, [1, 10, 100, 500], 'JPY'],
    ['FRA40', 'CAC 40 · EUR', 1, IDX, 'EUR'], ['AUS200', 'ASX 200 · AUD', 1, IDX, 'AUD'], ['HK50', 'Hang Seng · HKD', 1, IDX, 'HKD']]) },
  energy: { label: 'Energy', unit: '$ price move', items: mk([['USOIL', 'WTI crude (XTIUSD)', 1000, [10, 100, 1000]], ['UKOIL', 'Brent crude (XBRUSD)', 1000, [10, 100, 1000]], ['NGAS', 'Natural gas (XNGUSD)', 10000, [100, 1000, 10000]]]) },
  crypto: { label: 'Crypto', unit: '$ price move', items: mk([['BTCUSD', 'Bitcoin', 1, [0.1, 1, 10]], ['ETHUSD', 'Ethereum', 1, [1, 10, 100]], ['SOLUSD', 'Solana', 1, [1, 10, 100]], ['XRPUSD', 'XRP', 1, [1, 100, 1000]], ['LTCUSD', 'Litecoin', 1, [1, 10, 100]]]) },
};
export const STEPS = [0.001, 0.01, 0.1, 1];
export const DEC = { 0.001: 3, 0.01: 2, 0.1: 1, 1: 0 };
