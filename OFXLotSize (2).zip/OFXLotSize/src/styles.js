import { StyleSheet, Platform, StatusBar } from 'react-native';
import { C } from './theme';

export const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) : 54 },
  scroll: { padding: 18, paddingBottom: 60 },
  title: { color: C.text, fontSize: 28, fontWeight: '800' },
  sub: { color: C.mut, fontSize: 14, marginTop: 2, marginBottom: 18 },
  tabs: { flexDirection: 'row', marginBottom: 12 },
  chip: { paddingVertical: 9, paddingHorizontal: 13, borderRadius: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.line, marginRight: 6, marginBottom: 6 },
  chipOn: { backgroundColor: C.acc, borderColor: C.acc },
  chipT: { color: C.mut, fontSize: 13, fontWeight: '600' },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.line, marginBottom: 14 },
  label: { color: C.mut, fontSize: 13, marginBottom: 6 },
  hint: { color: C.mut, fontSize: 12, marginTop: 6, lineHeight: 17 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.bg, borderRadius: 10, borderWidth: 1, borderColor: C.line, paddingHorizontal: 12 },
  input: { flex: 1, color: C.text, fontSize: 17, paddingVertical: 11 },
  suffix: { color: C.mut, fontSize: 13, marginLeft: 8 },
  toggle: { backgroundColor: C.card, borderRadius: 8, paddingVertical: 6, paddingHorizontal: 10 },
  toggleT: { color: C.acc, fontSize: 13, fontWeight: '700' },
  big: { color: C.text, fontSize: 48, fontWeight: '800', marginVertical: 4 },
  bigU: { color: C.mut, fontSize: 18, fontWeight: '600' },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderTopWidth: 1, borderTopColor: C.line, marginTop: 4 },
  rowK: { color: C.mut, fontSize: 14 },
  rowV: { color: C.text, fontSize: 14, fontWeight: '700' },
  foot: { color: C.mut, fontSize: 11, textAlign: 'center', lineHeight: 16, marginTop: 4 },
  linkBtn: { alignSelf: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  link: { color: C.acc, fontSize: 13, fontWeight: '600', textDecorationLine: 'underline' },
});
