export const C = { bg: '#0E1726', card: '#16233A', line: '#25344F', text: '#EAF0FB', mut: '#8D9BB5', acc: '#4F8CFF', ok: '#34D399', bad: '#F87171' };
