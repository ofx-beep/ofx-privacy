export const num = (s) => parseFloat(String(s).replace(',', '.'));
export const usd = (n) => (n < 0 ? '-$' : '$') + Math.abs(n).toFixed(2);
